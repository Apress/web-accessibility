<?php 
	echo 'This is send.php';
?>