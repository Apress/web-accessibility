<?php 
	echo 'This is otherscript.php';
?>