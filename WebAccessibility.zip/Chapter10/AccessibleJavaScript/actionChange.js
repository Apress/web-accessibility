window.onload = function() {
	var f=document.getElementById('contactform');
	if(f)
	{
	  f.setAttribute('action','otherscript.php');
	}
}