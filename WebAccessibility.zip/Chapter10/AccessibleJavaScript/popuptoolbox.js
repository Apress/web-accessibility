
/*
	The popup window toolbox version 1.0
	Turns every link with a target of _blank or a rel of popup into a link
	opening a popup window and every link with a rev of popuptrigger to a link
	closing the current window.	
*/
function popuptools()
{
	// test if DOM is available
	if(!document.getElementById || !document.createTextNode){return;}
	// define variables
	// target to indicate popup link
	var triggerTarget='_blank';
	// rel to indicate popup link
	var triggerRel='popup';
	// rev to indicate closing link
	var backRev='poptrigger';
	// message to add to a link with a popup rev but no target
	var openMessage=' (opens in a new window)';
	// message to replace back links with
	var closeMessage='Close window';
	// links to loop over (it is a good idea to constrain this further)
	var links=document.getElementsByTagName('a');
	// If the window is a popup window (there is a opener window)
	if(window.opener)
	{
		// define new regular expression to test for the rev attribute
		var check = new RegExp("(^|\\s)" + backRev + "(\\s|$)");
		// loop over all links
		for(var i=0;i<links.length;i++)
		{
			// if there is no appropriate rev attribute, skip this link
			if(!check.test(links[i].getAttribute('rev'))){continue;}
			// if the closing message is not empty, replace the link text with it
			if(closeMessage!=''){links[i].firstChild.nodeValue=closeMessage;}
			// close the window when the link is activated
			addEvent(links[i],'click',dealwithwin);

		}
	// if the window is not a popup
	} else {
		// loop over all links
		for(var i=0;i<links.length;i++)
		{
			// if the link has no appropriate rel or target attribute skip it
			if(links[i].getAttribute('rel')!=triggerRel && 
			links[i].getAttribute('target')!=triggerTarget)
			{continue;}
			// if the link has no target, add the open message
			if(!links[i].target)
			{
				links[i].appendChild(document.createTextNode(openMessage));
			}
			// open a new window with the defined attributes when the 
			// link gets activated and set the focus to the window.
			addEvent(links[i],'click',dealwithwin,false);
		}
	}
}
function dealwithwin(e)
{
	var el;
	if (window.event && window.event.srcElement) el = window.event.srcElement;
	if (e && e.target) el = e.target;
	if (!el) return;
	var popupname='popup';
	var windowAttributes='width=400,height=400,scrollbars=yes,resizable=yes,menubar=yes';
	if(!window.opener)
	{
		var popup=window.open(el.href,popupname,windowAttributes);
		// if the popup was not blocked
		if(popup)
		{
			popup.focus();
			if(e.returnValue){e.returnValue = false;}
		    if(e.preventDefault){e.preventDefault();}
		    return false;
		}
	} else {
		window.close();
	}
}
function addEvent(elm, evType, fn, useCapture)
// cross-browser event handling for IE5+, NS6+ and Mozilla/Gecko
// By Scott Andrew
{
  if (elm.addEventListener) {
    elm.addEventListener(evType, fn, useCapture); 
    return true; 
  } else if (elm.attachEvent) {
    var r = elm.attachEvent('on' + evType, fn); 
    return r; 
  } else {
    elm['on' + evType] = fn;
  }
}
addEvent(window,'load',popuptools,false);


