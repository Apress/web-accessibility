These are the examples discussed in Chapter 10 of 
"WEB ACCESSIBILITY: WEB STANDARDS AND REGULATORY COMPLIANCE". 

Simply open index.html in a browser to reach them.

The example that dynamically changes the action of the form only works on a 
server with PHP enabled.

regards,
Chris Heilmann
